"""R vs Python comparison utility: Closed System Validation."""
from .validation import *
